#include"hello_c.h"
#include <string>
int main()
{
	Printer p1;
	std::cout << p1.Print("hello world!") << std::endl;
	return 0;

}