#include "hello_c.h"
Printer::Printer() {};
Printer::~Printer() {};
std::string Printer::Print(std::string name)
{
	return name;
}