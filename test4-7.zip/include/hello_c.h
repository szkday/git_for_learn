#pragma once
#include<iostream>
class Printer
{
public:
	Printer();
	~Printer();
	std::string Printer::Print(std::string name);
private:
	std::string name1;

};
